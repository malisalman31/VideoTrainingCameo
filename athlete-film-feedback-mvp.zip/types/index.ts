export type UserRole = "admin" | "customer";

export type PaymentStatus = "unpaid" | "paid" | "refunded";

export type SubmissionStatus = "submitted" | "in_review" | "completed";

export interface Profile {
  id: string;
  email: string;
  role: UserRole;
  full_name: string;
  created_at: string;
}

export interface Submission {
  id: string;
  customer_name: string;
  customer_email: string;
  sport: string;
  position: string;
  video_url: string | null;
  video_file_path: string | null;
  notes: string;
  stripe_checkout_session_id: string | null;
  payment_status: PaymentStatus;
  submission_status: SubmissionStatus;
  feedback_text: string | null;
  feedback_video_url: string | null;
  feedback_video_file_path: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
}

export interface DashboardMetrics {
  total: number;
  submitted: number;
  inReview: number;
  completed: number;
}

export interface OrderPayload {
  customerName: string;
  customerEmail: string;
  sport: string;
  position: string;
  videoUrl?: string;
  notes: string;
  uploadedFileName?: string;
}
