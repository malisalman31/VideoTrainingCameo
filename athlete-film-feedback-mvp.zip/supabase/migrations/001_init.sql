create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  role text not null check (role in ('admin', 'customer')),
  full_name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.submissions (
  id text primary key,
  customer_name text not null,
  customer_email text not null,
  sport text not null,
  position text not null,
  video_url text,
  video_file_path text,
  notes text not null,
  stripe_checkout_session_id text,
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid', 'paid', 'refunded')),
  submission_status text not null default 'submitted' check (submission_status in ('submitted', 'in_review', 'completed')),
  feedback_text text,
  feedback_video_url text,
  feedback_video_file_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz
);

alter table public.profiles enable row level security;
alter table public.submissions enable row level security;

-- Replace auth.email() checks with your preferred ownership model.
create policy "customers can read own submissions"
on public.submissions
for select
using (customer_email = auth.email());

create policy "admins can manage all submissions"
on public.submissions
for all
using (
  exists (
    select 1
    from public.profiles
    where profiles.email = auth.email()
      and profiles.role = 'admin'
  )
)
with check (
  exists (
    select 1
    from public.profiles
    where profiles.email = auth.email()
      and profiles.role = 'admin'
  )
);

-- Storage bucket and policies should mirror submission-specific folders.
