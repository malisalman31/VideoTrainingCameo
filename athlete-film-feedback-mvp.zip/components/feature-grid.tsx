import { Film, MessageSquareText, TimerReset } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    title: "Upload game film or drill clips",
    description: "Send a file or paste a video link. Add notes about the exact skills or sequences you want reviewed.",
    icon: Film
  },
  {
    title: "Receive personalized technical feedback",
    description: "Get direct coaching on movement patterns, reads, mechanics, and execution from one elite athlete.",
    icon: MessageSquareText
  },
  {
    title: "Track progress in one portal",
    description: "See when your review is submitted, in progress, and complete. Revisit written notes and video responses anytime.",
    icon: TimerReset
  }
];

export function FeatureGrid() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-20">
      <div className="grid gap-5 md:grid-cols-3">
        {features.map((feature) => (
          <Card key={feature.title} className="bg-white/70">
            <CardContent className="space-y-4">
              <feature.icon className="h-8 w-8 text-primary" />
              <div className="space-y-2">
                <h3 className="text-xl font-semibold">{feature.title}</h3>
                <p className="text-sm leading-7 text-muted-foreground">{feature.description}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
