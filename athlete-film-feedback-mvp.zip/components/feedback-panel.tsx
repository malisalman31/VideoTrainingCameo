import { CirclePlay } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";

export function FeedbackPanel({
  feedbackText,
  feedbackVideoUrl
}: {
  feedbackText: string | null;
  feedbackVideoUrl: string | null;
}) {
  return (
    <Card>
      <CardContent className="space-y-5">
        <div className="space-y-2">
          <h2 className="text-xl font-semibold">Athlete Feedback</h2>
          <p className="text-sm text-muted-foreground">
            Completed reviews appear here with written notes and any linked response video.
          </p>
        </div>
        {feedbackText ? (
          <div className="rounded-2xl bg-accent/70 p-5 text-sm leading-7 text-foreground">
            {feedbackText}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-border p-5 text-sm text-muted-foreground">
            Feedback will appear here once the athlete completes the review.
          </div>
        )}
        {feedbackVideoUrl ? (
          <a
            href={feedbackVideoUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-sm font-medium text-primary"
          >
            <CirclePlay className="h-4 w-4" />
            Watch feedback video
          </a>
        ) : null}
      </CardContent>
    </Card>
  );
}
