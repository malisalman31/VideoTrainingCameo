import type { ReactNode } from "react";
import { LockKeyhole } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { hasSupabaseEnv } from "@/lib/supabase";

export function ProtectedRoute({
  children,
  previewMessage = "Supabase auth is not configured, so admin pages are displayed in preview mode."
}: {
  children: ReactNode;
  previewMessage?: string;
}) {
  return (
    <div className="space-y-6">
      {!hasSupabaseEnv() ? (
        <Card className="border-amber-500/30 bg-amber-500/10">
          <CardContent className="flex items-start gap-3 py-4">
            <LockKeyhole className="mt-0.5 h-5 w-5 text-amber-700" />
            <p className="text-sm text-amber-900">{previewMessage}</p>
          </CardContent>
        </Card>
      ) : null}
      {children}
    </div>
  );
}
