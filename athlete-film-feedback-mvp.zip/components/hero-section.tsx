import Link from "next/link";
import { Play, ShieldCheck, Video } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { siteConfig } from "@/lib/site";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden px-6 pb-16 pt-14 md:pb-24 md:pt-20">
      <div className="absolute inset-0 -z-10 bg-hero-grid bg-hero-grid opacity-70" />
      <div className="absolute inset-x-0 top-0 -z-10 h-96 bg-[radial-gradient(circle_at_top,rgba(245,158,11,0.2),transparent_45%)]" />
      <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
        <div className="space-y-8">
          <Badge>Elite Athlete Review</Badge>
          <div className="space-y-4">
            <h1 className="max-w-3xl text-5xl font-semibold tracking-tight text-foreground md:text-7xl">
              Upload your film. Receive expert analysis.
            </h1>
            <p className="max-w-2xl text-lg leading-8 text-muted-foreground">
              Direct insight from an elite athlete. Submit game film, drills, or training clips and get precise, personalized feedback on technique, timing, and decision-making.
            </p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Link href="/order">
              <Button size="lg">Purchase Review</Button>
            </Link>
            <a href="#how-it-works">
              <Button variant="outline" size="lg">
                See Process
              </Button>
            </a>
          </div>
          <div className="grid gap-4 text-sm text-muted-foreground sm:grid-cols-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-primary" />
              Premium review workflow
            </div>
            <div className="flex items-center gap-2">
              <Video className="h-4 w-4 text-primary" />
              Written notes or video response
            </div>
            <div className="flex items-center gap-2">
              <Play className="h-4 w-4 text-primary" />
              Built for mobile submission
            </div>
          </div>
        </div>
        <Card className="border-white/10 bg-slate-950 text-slate-50 shadow-glow">
          <CardContent className="space-y-5 p-8">
            <div className="space-y-2">
              <p className="text-sm uppercase tracking-[0.2em] text-amber-300">Session Offer</p>
              <p className="text-4xl font-semibold">{siteConfig.priceLabel}</p>
              <p className="text-sm text-slate-300">{siteConfig.priceDescription}</p>
            </div>
            <div className="space-y-4 text-sm text-slate-200">
              <div className="flex justify-between gap-4 border-b border-white/10 pb-3">
                <span>Film review depth</span>
                <span>Technical breakdown</span>
              </div>
              <div className="flex justify-between gap-4 border-b border-white/10 pb-3">
                <span>Response format</span>
                <span>Written + optional video</span>
              </div>
              <div className="flex justify-between gap-4">
                <span>Portal access</span>
                <span>Track status anytime</span>
              </div>
            </div>
            <Link href="/order" className="block">
              <Button className="w-full" size="lg">
                Start Submission
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
