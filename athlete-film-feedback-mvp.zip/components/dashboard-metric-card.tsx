import { Card, CardContent } from "@/components/ui/card";

export function DashboardMetricCard({
  label,
  value
}: {
  label: string;
  value: number;
}) {
  return (
    <Card>
      <CardContent className="space-y-2">
        <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground">{label}</p>
        <p className="text-4xl font-semibold tracking-tight">{value}</p>
      </CardContent>
    </Card>
  );
}
