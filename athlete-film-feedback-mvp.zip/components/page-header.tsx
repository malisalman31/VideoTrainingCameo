export function PageHeader({
  eyebrow,
  title,
  description
}: {
  eyebrow?: string;
  title: string;
  description: string;
}) {
  return (
    <div className="space-y-3">
      {eyebrow ? <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground">{eyebrow}</p> : null}
      <h1 className="text-4xl font-semibold tracking-tight md:text-5xl">{title}</h1>
      <p className="max-w-3xl text-base leading-7 text-muted-foreground">{description}</p>
    </div>
  );
}
