import { submitOrder } from "@/app/order/actions";
import { Card, CardContent } from "@/components/ui/card";
import { isDemoMode } from "@/lib/submissions";

export function SubmissionForm() {
  return (
    <Card>
      <CardContent className="space-y-6">
        <form action={submitOrder} className="grid gap-5">
          <div className="grid gap-5 md:grid-cols-2">
            <label className="grid gap-2 text-sm font-medium">
              Name
              <input
                required
                name="customerName"
                placeholder="Full name"
                className="h-12 rounded-2xl border border-border bg-background px-4"
              />
            </label>
            <label className="grid gap-2 text-sm font-medium">
              Email
              <input
                required
                type="email"
                name="customerEmail"
                placeholder="you@example.com"
                className="h-12 rounded-2xl border border-border bg-background px-4"
              />
            </label>
          </div>
          <div className="grid gap-5 md:grid-cols-2">
            <label className="grid gap-2 text-sm font-medium">
              Sport
              <input required name="sport" placeholder="Basketball" className="h-12 rounded-2xl border border-border bg-background px-4" />
            </label>
            <label className="grid gap-2 text-sm font-medium">
              Position
              <input required name="position" placeholder="Guard" className="h-12 rounded-2xl border border-border bg-background px-4" />
            </label>
          </div>
          <div className="grid gap-5">
            <label className="grid gap-2 text-sm font-medium">
              Upload footage
              <input
                type="file"
                name="videoFile"
                accept="video/*"
                className="rounded-2xl border border-dashed border-border bg-background px-4 py-5 text-sm text-muted-foreground"
              />
            </label>
            <label className="grid gap-2 text-sm font-medium">
              Or paste a video link
              <input
                name="videoUrl"
                placeholder="https://youtube.com/..."
                className="h-12 rounded-2xl border border-border bg-background px-4"
              />
            </label>
          </div>
          <label className="grid gap-2 text-sm font-medium">
            Notes or questions
            <textarea
              required
              name="notes"
              rows={6}
              placeholder="What specific skills, sequences, or decisions do you want reviewed?"
              className="rounded-2xl border border-border bg-background px-4 py-3"
            />
          </label>
          <button
            type="submit"
            className="h-12 rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground transition hover:bg-primary/90"
          >
            Continue to Checkout
          </button>
        </form>
        {isDemoMode() ? (
          <p className="text-sm text-muted-foreground">
            Demo mode is active. Checkout redirects to a success page placeholder until Stripe and Supabase storage are configured.
          </p>
        ) : null}
      </CardContent>
    </Card>
  );
}
