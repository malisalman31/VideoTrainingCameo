import type { SubmissionStatus } from "@/types";
import { cn } from "@/lib/utils";

const labels: Record<SubmissionStatus, string> = {
  submitted: "Submitted",
  in_review: "In Review",
  completed: "Completed"
};

const classes: Record<SubmissionStatus, string> = {
  submitted: "border-amber-500/30 bg-amber-500/10 text-amber-700",
  in_review: "border-sky-500/30 bg-sky-500/10 text-sky-700",
  completed: "border-emerald-500/30 bg-emerald-500/10 text-emerald-700"
};

export function StatusBadge({ status }: { status: SubmissionStatus }) {
  return (
    <span className={cn("inline-flex rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em]", classes[status])}>
      {labels[status]}
    </span>
  );
}
