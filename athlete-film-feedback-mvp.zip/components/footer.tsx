export function Footer() {
  return (
    <footer className="border-t border-border/60 py-10">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 px-6 text-sm text-muted-foreground md:flex-row md:items-center md:justify-between">
        <p>Premium athlete film feedback. Built for fast technical clarity.</p>
        <p>FrameIQ MVP</p>
      </div>
    </footer>
  );
}
