import Link from "next/link";
import { Check } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { siteConfig } from "@/lib/site";

export function PricingCard() {
  const inclusions = [
    "One personalized athlete review",
    "Technical notes focused on your questions",
    "Status tracking in your customer portal",
    "Optional video response when useful"
  ];

  return (
    <Card id="pricing" className="mx-auto max-w-3xl border-slate-900 bg-slate-950 text-slate-50 shadow-glow">
      <CardContent className="grid gap-8 p-8 md:grid-cols-[0.8fr_1.2fr] md:p-10">
        <div className="space-y-2">
          <p className="text-sm uppercase tracking-[0.2em] text-amber-300">Pricing</p>
          <p className="text-5xl font-semibold">{siteConfig.priceLabel}</p>
          <p className="text-sm leading-7 text-slate-300">{siteConfig.priceDescription}</p>
        </div>
        <div className="space-y-4">
          {inclusions.map((item) => (
            <div key={item} className="flex items-center gap-3 text-sm text-slate-200">
              <Check className="h-4 w-4 text-amber-300" />
              <span>{item}</span>
            </div>
          ))}
          <Link href="/order" className="block pt-2">
            <Button size="lg" className="w-full">
              Purchase Review
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
