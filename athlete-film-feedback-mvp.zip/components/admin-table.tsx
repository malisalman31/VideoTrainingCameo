import Link from "next/link";

import { StatusBadge } from "@/components/status-badge";
import type { Submission } from "@/types";
import { formatDate } from "@/lib/utils";

export function AdminTable({ submissions }: { submissions: Submission[] }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-border bg-card">
      <table className="min-w-full divide-y divide-border text-sm">
        <thead className="bg-accent/50 text-left text-muted-foreground">
          <tr>
            <th className="px-4 py-3 font-medium">Customer</th>
            <th className="px-4 py-3 font-medium">Sport</th>
            <th className="px-4 py-3 font-medium">Status</th>
            <th className="px-4 py-3 font-medium">Payment</th>
            <th className="px-4 py-3 font-medium">Date</th>
            <th className="px-4 py-3 font-medium" />
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {submissions.map((submission) => (
            <tr key={submission.id}>
              <td className="px-4 py-4">
                <div className="font-medium">{submission.customer_name}</div>
                <div className="text-muted-foreground">{submission.customer_email}</div>
              </td>
              <td className="px-4 py-4">
                {submission.sport}
                <div className="text-muted-foreground">{submission.position}</div>
              </td>
              <td className="px-4 py-4">
                <StatusBadge status={submission.submission_status} />
              </td>
              <td className="px-4 py-4 capitalize">{submission.payment_status}</td>
              <td className="px-4 py-4">{formatDate(submission.created_at)}</td>
              <td className="px-4 py-4 text-right">
                <Link className="font-medium text-primary" href={`/admin/submissions/${submission.id}`}>
                  View
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
