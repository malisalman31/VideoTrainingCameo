# Athlete Film Feedback MVP

Next.js MVP for a single-athlete film review product. The app includes:

- Premium landing page
- Order form with a Stripe checkout placeholder flow
- Customer submission status page
- Admin login, dashboard, and submission detail views
- Supabase and Stripe helper modules with clear integration seams

## Local setup

1. Install dependencies: `npm install`
2. Copy `.env.example` to `.env.local`
3. Run `npm run dev`

## Integration notes

- Without Supabase and Stripe env vars, the app runs in demo mode using typed mock data.
- Supabase helpers live in [`/Users/chadhansen/Documents/Playground/lib/supabase.ts`](/Users/chadhansen/Documents/Playground/lib/supabase.ts).
- Stripe checkout placeholder logic lives in [`/Users/chadhansen/Documents/Playground/lib/stripe.ts`](/Users/chadhansen/Documents/Playground/lib/stripe.ts).
- RLS assumption: customers can view only their own submission by signed link or authenticated identity; admin can read/update all submissions.
