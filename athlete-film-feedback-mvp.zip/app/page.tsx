import Link from "next/link";
import { ArrowRight, BadgeCheck, ChevronRight, Star } from "lucide-react";

import { FeatureGrid } from "@/components/feature-grid";
import { Footer } from "@/components/footer";
import { HeroSection } from "@/components/hero-section";
import { Navbar } from "@/components/navbar";
import { PricingCard } from "@/components/pricing-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const faqs = [
  {
    question: "What kind of footage can I send?",
    answer: "Game film, practice clips, drill sessions, or any video that clearly shows the skill or decision-making sequence you want reviewed."
  },
  {
    question: "How do I receive the feedback?",
    answer: "You get written notes in your portal. When a sequence needs more context, the athlete can add a linked response video."
  },
  {
    question: "Can I ask specific questions?",
    answer: "Yes. The order form includes a notes field so you can focus the review on mechanics, reads, positioning, timing, or any skill detail."
  }
];

const credibilityItems = [
  "Single-athlete expert workflow",
  "Premium one-on-one positioning",
  "Built for focused technical feedback"
];

export default function Home() {
  return (
    <main>
      <Navbar />
      <HeroSection />
      <FeatureGrid />

      <section id="how-it-works" className="mx-auto max-w-6xl px-6 py-20">
        <div className="mb-10 max-w-2xl space-y-3">
          <Badge>How It Works</Badge>
          <h2 className="text-4xl font-semibold tracking-tight">Three steps from film upload to finished review.</h2>
          <p className="text-base leading-7 text-muted-foreground">
            The product is designed for one clear outcome: fast, premium technical feedback without extra platform complexity.
          </p>
        </div>
        <div className="grid gap-5 md:grid-cols-3">
          {[
            ["1", "Submit your footage", "Upload a clip or paste a link, then tell the athlete exactly what you want analyzed."],
            ["2", "Review begins", "Your session moves into review and the athlete can assess the film, notes, and payment details."],
            ["3", "Get personalized feedback", "Open your submission page to read the breakdown and watch any attached response video."]
          ].map(([step, title, body]) => (
            <Card key={step}>
              <CardContent className="space-y-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  {step}
                </div>
                <h3 className="text-xl font-semibold">{title}</h3>
                <p className="text-sm leading-7 text-muted-foreground">{body}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-6 py-10 lg:grid-cols-[0.9fr_1.1fr]">
        <Card className="bg-slate-950 text-slate-50">
          <CardContent className="space-y-5 p-8">
            <div className="flex items-center gap-2 text-amber-300">
              <Star className="h-4 w-4 fill-current" />
              <span className="text-sm uppercase tracking-[0.2em]">Credibility</span>
            </div>
            <h2 className="text-3xl font-semibold tracking-tight">Positioned like a premium direct-access coaching offer.</h2>
            <div className="space-y-3 text-sm text-slate-300">
              {credibilityItems.map((item) => (
                <div key={item} className="flex items-center gap-3">
                  <BadgeCheck className="h-4 w-4 text-amber-300" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <div className="grid gap-5">
          <Card>
            <CardContent className="space-y-3">
              <h3 className="text-2xl font-semibold">What you receive</h3>
              <p className="text-sm leading-7 text-muted-foreground">
                Clear technical instruction, individualized notes, and a simple portal experience that keeps focus on the review itself.
              </p>
            </CardContent>
          </Card>
          <PricingCard />
        </div>
      </section>

      <section id="faq" className="mx-auto max-w-6xl px-6 py-20">
        <div className="mb-10 max-w-2xl space-y-3">
          <Badge>FAQ</Badge>
          <h2 className="text-4xl font-semibold tracking-tight">Common questions before submitting film.</h2>
        </div>
        <div className="grid gap-5 md:grid-cols-3">
          {faqs.map((faq) => (
            <Card key={faq.question}>
              <CardContent className="space-y-3">
                <h3 className="text-xl font-semibold">{faq.question}</h3>
                <p className="text-sm leading-7 text-muted-foreground">{faq.answer}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-24">
        <Card className="border-slate-900 bg-slate-950 text-slate-50">
          <CardContent className="flex flex-col gap-6 p-8 md:flex-row md:items-center md:justify-between md:p-10">
            <div className="space-y-2">
              <h2 className="text-3xl font-semibold tracking-tight">Receive personalized feedback on your technique.</h2>
              <p className="max-w-2xl text-sm leading-7 text-slate-300">
                Submit your footage, complete checkout, and get direct analysis without waiting on a marketplace or a generic coaching feed.
              </p>
            </div>
            <Link href="/order">
              <Button size="lg" className="gap-2">
                Start Your Submission
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>
        <div className="mt-6 flex justify-end">
          <Link href="/submission/sub_103" className="inline-flex items-center gap-1 text-sm font-medium text-muted-foreground">
            View demo customer portal
            <ChevronRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
      <Footer />
    </main>
  );
}
