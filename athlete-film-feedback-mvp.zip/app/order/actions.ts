"use server";

import { redirect } from "next/navigation";

import { createCheckoutSession } from "@/lib/stripe";
import type { OrderPayload } from "@/types";

export async function submitOrder(formData: FormData) {
  const order: OrderPayload = {
    customerName: String(formData.get("customerName") || "").trim(),
    customerEmail: String(formData.get("customerEmail") || "").trim(),
    sport: String(formData.get("sport") || "").trim(),
    position: String(formData.get("position") || "").trim(),
    videoUrl: String(formData.get("videoUrl") || "").trim(),
    notes: String(formData.get("notes") || "").trim(),
    uploadedFileName: (formData.get("videoFile") as File | null)?.name
  };

  if (!order.customerName || !order.customerEmail || !order.sport || !order.position || !order.notes) {
    redirect("/order?error=Please+complete+all+required+fields");
  }

  const session = await createCheckoutSession(order);
  redirect(session.checkoutUrl);
}
