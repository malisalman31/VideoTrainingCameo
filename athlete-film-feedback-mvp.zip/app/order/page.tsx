import { PageHeader } from "@/components/page-header";
import { SubmissionForm } from "@/components/submission-form";

export default async function OrderPage({
  searchParams
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;

  return (
    <main className="mx-auto max-w-4xl px-6 py-14">
      <div className="space-y-8">
        <PageHeader
          eyebrow="Order"
          title="Submit your film for personalized feedback."
          description="Complete the session request below. Customers can upload a clip or paste a video link, include notes, and continue into Stripe Checkout."
        />
        {error ? (
          <div className="rounded-2xl border border-danger/20 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
        ) : null}
        <SubmissionForm />
      </div>
    </main>
  );
}
