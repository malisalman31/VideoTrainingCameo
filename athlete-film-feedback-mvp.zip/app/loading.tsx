export default function Loading() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-16">
      <div className="space-y-4">
        <div className="h-4 w-28 animate-pulse rounded-full bg-muted" />
        <div className="h-12 w-full max-w-2xl animate-pulse rounded-2xl bg-muted" />
        <div className="h-6 w-full max-w-3xl animate-pulse rounded-2xl bg-muted" />
        <div className="grid gap-5 md:grid-cols-2">
          <div className="h-64 animate-pulse rounded-3xl bg-card" />
          <div className="h-64 animate-pulse rounded-3xl bg-card" />
        </div>
      </div>
    </main>
  );
}
