import Link from "next/link";
import { CheckCircle2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default async function CheckoutSuccessPage({
  searchParams
}: {
  searchParams: Promise<{ submissionId?: string; demo?: string }>;
}) {
  const { submissionId = "sub_103", demo } = await searchParams;

  return (
    <main className="mx-auto max-w-3xl px-6 py-20">
      <Card className="border-emerald-500/20 bg-white/90">
        <CardContent className="space-y-6 p-8 md:p-10">
          <CheckCircle2 className="h-12 w-12 text-emerald-600" />
          <div className="space-y-2">
            <h1 className="text-4xl font-semibold tracking-tight">Submission received.</h1>
            <p className="text-base leading-7 text-muted-foreground">
              Your session is in the queue. Use the portal link below to track review status and view completed feedback.
            </p>
          </div>
          {demo ? (
            <div className="rounded-2xl border border-amber-500/20 bg-amber-50 px-4 py-3 text-sm text-amber-800">
              Demo checkout mode is active. Replace the Stripe placeholder in the server action to create live checkout sessions.
            </div>
          ) : null}
          <div className="flex flex-col gap-3 sm:flex-row">
            <Link href={`/submission/${submissionId}`}>
              <Button size="lg">Open Submission Portal</Button>
            </Link>
            <Link href="/">
              <Button variant="outline" size="lg">
                Return Home
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
