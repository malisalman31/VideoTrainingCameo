"use client";

export default function Error({
  error,
  reset
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="mx-auto max-w-3xl px-6 py-20">
      <div className="rounded-3xl border border-danger/20 bg-white/90 p-8">
        <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground">Error</p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight">Something interrupted the workflow.</h1>
        <p className="mt-3 text-sm leading-7 text-muted-foreground">
          {error.message || "The page could not finish loading."}
        </p>
        <button
          type="button"
          onClick={reset}
          className="mt-6 h-11 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground"
        >
          Try again
        </button>
      </div>
    </main>
  );
}
