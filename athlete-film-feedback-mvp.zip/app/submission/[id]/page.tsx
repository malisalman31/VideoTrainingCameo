import Link from "next/link";

import { FeedbackPanel } from "@/components/feedback-panel";
import { PageHeader } from "@/components/page-header";
import { StatusBadge } from "@/components/status-badge";
import { Card, CardContent } from "@/components/ui/card";
import { getSubmission } from "@/lib/submissions";
import { formatDate } from "@/lib/utils";

export default async function SubmissionPage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const submission = await getSubmission(id);

  return (
    <main className="mx-auto max-w-5xl px-6 py-14">
      <div className="space-y-8">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <PageHeader
            eyebrow="Customer Portal"
            title={`${submission.customer_name}'s submission`}
            description="Track review progress and access completed athlete feedback here."
          />
          <StatusBadge status={submission.submission_status} />
        </div>
        <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <Card>
            <CardContent className="space-y-5">
              <div className="space-y-1">
                <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground">Submission details</p>
                <h2 className="text-2xl font-semibold">{submission.sport}</h2>
              </div>
              <div className="grid gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Position</p>
                  <p className="font-medium">{submission.position}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Submitted</p>
                  <p className="font-medium">{formatDate(submission.created_at)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Payment</p>
                  <p className="font-medium capitalize">{submission.payment_status}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Video</p>
                  {submission.video_url ? (
                    <a href={submission.video_url} target="_blank" rel="noreferrer" className="font-medium text-primary">
                      Open submitted video
                    </a>
                  ) : (
                    <p className="font-medium">{submission.video_file_path ?? "Uploaded file pending storage link"}</p>
                  )}
                </div>
                <div>
                  <p className="text-muted-foreground">Notes</p>
                  <p className="leading-7">{submission.notes}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <FeedbackPanel feedbackText={submission.feedback_text} feedbackVideoUrl={submission.feedback_video_url} />
        </div>
        <Link href="/" className="text-sm font-medium text-muted-foreground">
          Return to home
        </Link>
      </div>
    </main>
  );
}
