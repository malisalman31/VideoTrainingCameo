import type { Metadata } from "next";
import type { ReactNode } from "react";

import "@/app/globals.css";

export const metadata: Metadata = {
  title: "FrameIQ | Elite Athlete Film Feedback",
  description: "Premium athlete film review MVP built with Next.js, Supabase, and Stripe placeholders."
};

export default function RootLayout({
  children
}: Readonly<{
  children: ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
