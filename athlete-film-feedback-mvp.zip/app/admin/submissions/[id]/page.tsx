import Link from "next/link";

import { PageHeader } from "@/components/page-header";
import { ProtectedRoute } from "@/components/protected-route";
import { StatusBadge } from "@/components/status-badge";
import { Card, CardContent } from "@/components/ui/card";
import { getSubmission } from "@/lib/submissions";
import { formatDate } from "@/lib/utils";

export default async function AdminSubmissionDetailPage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const submission = await getSubmission(id);

  return (
    <main className="mx-auto max-w-6xl px-6 py-14">
      <ProtectedRoute>
        <div className="space-y-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <PageHeader
              eyebrow="Submission Detail"
              title={submission.customer_name}
              description="Review the original submission, inspect payment and status, then attach written or video feedback."
            />
            <StatusBadge status={submission.submission_status} />
          </div>
          <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
            <Card>
              <CardContent className="space-y-5">
                <div className="grid gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Email</p>
                    <p className="font-medium">{submission.customer_email}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Sport / position</p>
                    <p className="font-medium">
                      {submission.sport} / {submission.position}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Created</p>
                    <p className="font-medium">{formatDate(submission.created_at)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Payment status</p>
                    <p className="font-medium capitalize">{submission.payment_status}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Source video</p>
                    {submission.video_url ? (
                      <a href={submission.video_url} target="_blank" rel="noreferrer" className="font-medium text-primary">
                        Open original footage
                      </a>
                    ) : (
                      <p className="font-medium">{submission.video_file_path ?? "Storage link pending"}</p>
                    )}
                  </div>
                  <div>
                    <p className="text-muted-foreground">Customer notes</p>
                    <p className="leading-7">{submission.notes}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="space-y-5">
                <div className="space-y-2">
                  <h2 className="text-xl font-semibold">Admin actions</h2>
                  <p className="text-sm text-muted-foreground">
                    Wire these controls to Supabase update mutations or server actions for live admin workflows.
                  </p>
                </div>
                <form className="grid gap-4">
                  <label className="grid gap-2 text-sm font-medium">
                    Submission status
                    <select defaultValue={submission.submission_status} className="h-12 rounded-2xl border border-border bg-background px-4">
                      <option value="submitted">Submitted</option>
                      <option value="in_review">In Review</option>
                      <option value="completed">Completed</option>
                    </select>
                  </label>
                  <label className="grid gap-2 text-sm font-medium">
                    Written feedback
                    <textarea
                      rows={7}
                      defaultValue={submission.feedback_text ?? ""}
                      placeholder="Add technical notes for the customer"
                      className="rounded-2xl border border-border bg-background px-4 py-3"
                    />
                  </label>
                  <label className="grid gap-2 text-sm font-medium">
                    Feedback video URL
                    <input
                      defaultValue={submission.feedback_video_url ?? ""}
                      placeholder="https://loom.com/..."
                      className="h-12 rounded-2xl border border-border bg-background px-4"
                    />
                  </label>
                  <label className="grid gap-2 text-sm font-medium">
                    Upload feedback video
                    <input type="file" className="rounded-2xl border border-dashed border-border bg-background px-4 py-5 text-sm text-muted-foreground" />
                  </label>
                  <div className="rounded-2xl border border-border bg-accent/40 px-4 py-3 text-sm text-muted-foreground">
                    Current MVP ships these controls as typed placeholders so the admin surface is ready before backend mutations are connected.
                  </div>
                  <button type="button" className="h-12 rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground">
                    Save Admin Update
                  </button>
                </form>
              </CardContent>
            </Card>
          </div>
          <Link href="/admin" className="text-sm font-medium text-muted-foreground">
            Back to dashboard
          </Link>
        </div>
      </ProtectedRoute>
    </main>
  );
}
