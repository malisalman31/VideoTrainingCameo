import Link from "next/link";

import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { hasSupabaseEnv } from "@/lib/supabase";

export default function AdminLoginPage() {
  return (
    <main className="mx-auto max-w-xl px-6 py-16">
      <div className="space-y-8">
        <PageHeader
          eyebrow="Admin"
          title="Athlete admin login"
          description="Supabase auth should back this page in production. The preview below keeps the MVP navigable until live auth is connected."
        />
        <Card>
          <CardContent className="space-y-5">
            <div className="grid gap-4">
              <label className="grid gap-2 text-sm font-medium">
                Email
                <input className="h-12 rounded-2xl border border-border bg-background px-4" placeholder="athlete@example.com" />
              </label>
              <label className="grid gap-2 text-sm font-medium">
                Password
                <input type="password" className="h-12 rounded-2xl border border-border bg-background px-4" placeholder="••••••••" />
              </label>
            </div>
            <div className="rounded-2xl border border-border bg-accent/40 px-4 py-3 text-sm text-muted-foreground">
              {hasSupabaseEnv()
                ? "Connect this form to Supabase auth.signInWithPassword."
                : "Preview mode: Supabase auth env vars are missing, so this form is non-functional by design."}
            </div>
            <Link href="/admin">
              <Button className="w-full" size="lg">
                Continue to Dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
