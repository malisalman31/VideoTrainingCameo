import { AdminTable } from "@/components/admin-table";
import { DashboardMetricCard } from "@/components/dashboard-metric-card";
import { PageHeader } from "@/components/page-header";
import { ProtectedRoute } from "@/components/protected-route";
import { EmptyState } from "@/components/empty-state";
import { getAllSubmissions, getMetrics } from "@/lib/submissions";

export default async function AdminPage() {
  const [submissions, metrics] = await Promise.all([getAllSubmissions(), getMetrics()]);

  return (
    <main className="mx-auto max-w-6xl px-6 py-14">
      <ProtectedRoute>
        <div className="space-y-8">
          <PageHeader
            eyebrow="Admin Dashboard"
            title="Manage incoming athlete review requests."
            description="See payment-backed submissions, move reviews through each stage, and open individual records to add feedback."
          />
          <div className="grid gap-5 md:grid-cols-4">
            <DashboardMetricCard label="Total submissions" value={metrics.total} />
            <DashboardMetricCard label="New submissions" value={metrics.submitted} />
            <DashboardMetricCard label="In review" value={metrics.inReview} />
            <DashboardMetricCard label="Completed" value={metrics.completed} />
          </div>
          {submissions.length ? (
            <AdminTable submissions={submissions} />
          ) : (
            <EmptyState title="No submissions yet" description="New paid orders will appear here once customers complete checkout." />
          )}
        </div>
      </ProtectedRoute>
    </main>
  );
}
