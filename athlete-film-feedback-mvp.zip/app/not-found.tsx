import Link from "next/link";

import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-20">
      <div className="rounded-3xl border border-border bg-white/90 p-8">
        <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground">404</p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight">Page not found.</h1>
        <p className="mt-3 text-sm leading-7 text-muted-foreground">
          The requested page is not available in this MVP route set.
        </p>
        <Link href="/" className="mt-6 inline-block">
          <Button>Return Home</Button>
        </Link>
      </div>
    </main>
  );
}
