import { cache } from "react";

import { demoSubmissions, getDashboardMetrics, getSubmissionById } from "@/lib/mock-data";
import type { DashboardMetrics, Submission } from "@/types";

const useDemoMode = !process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export const getAllSubmissions = cache(async (): Promise<Submission[]> => {
  if (useDemoMode) {
    return demoSubmissions;
  }

  // Replace with Supabase query when env vars are configured.
  return demoSubmissions;
});

export const getSubmission = cache(async (id: string): Promise<Submission> => {
  if (useDemoMode) {
    return getSubmissionById(id);
  }

  // Replace with Supabase select().eq("id", id).single()
  return getSubmissionById(id);
});

export async function getMetrics(): Promise<DashboardMetrics> {
  const submissions = await getAllSubmissions();
  return getDashboardMetrics(submissions);
}

export function isDemoMode() {
  return useDemoMode;
}
