import type { DashboardMetrics, Submission } from "@/types";

const now = new Date();

export const demoSubmissions: Submission[] = [
  {
    id: "sub_101",
    customer_name: "Jordan Lee",
    customer_email: "jordan@example.com",
    sport: "Basketball",
    position: "Guard",
    video_url: "https://www.youtube.com/watch?v=aqz-KE-bpKQ",
    video_file_path: null,
    notes: "Need feedback on shot prep and finishing footwork against contact.",
    stripe_checkout_session_id: "cs_demo_101",
    payment_status: "paid",
    submission_status: "submitted",
    feedback_text: null,
    feedback_video_url: null,
    feedback_video_file_path: null,
    created_at: now.toISOString(),
    updated_at: now.toISOString(),
    completed_at: null
  },
  {
    id: "sub_102",
    customer_name: "Avery Smith",
    customer_email: "avery@example.com",
    sport: "Soccer",
    position: "Forward",
    video_url: "https://vimeo.com/76979871",
    video_file_path: null,
    notes: "Please break down first-step explosiveness and timing of runs.",
    stripe_checkout_session_id: "cs_demo_102",
    payment_status: "paid",
    submission_status: "in_review",
    feedback_text: "Your first two steps are strong, but your trigger is late when the defender opens. Cue your run as the midfielder sets their second touch.",
    feedback_video_url: null,
    feedback_video_file_path: null,
    created_at: new Date(now.getTime() - 86400000).toISOString(),
    updated_at: new Date(now.getTime() - 3600000).toISOString(),
    completed_at: null
  },
  {
    id: "sub_103",
    customer_name: "Taylor Davis",
    customer_email: "taylor@example.com",
    sport: "Baseball",
    position: "Pitcher",
    video_url: "https://www.youtube.com/watch?v=jNQXAC9IVRw",
    video_file_path: null,
    notes: "Looking for command and lower-half sequencing feedback.",
    stripe_checkout_session_id: "cs_demo_103",
    payment_status: "paid",
    submission_status: "completed",
    feedback_text: "Your direction is clean, but your front hip opens early. Stay closed longer, then drive through release to improve glove-side command.",
    feedback_video_url: "https://www.loom.com/share/demo-feedback",
    feedback_video_file_path: null,
    created_at: new Date(now.getTime() - 172800000).toISOString(),
    updated_at: new Date(now.getTime() - 7200000).toISOString(),
    completed_at: new Date(now.getTime() - 7200000).toISOString()
  }
];

export function getDashboardMetrics(submissions: Submission[]): DashboardMetrics {
  return {
    total: submissions.length,
    submitted: submissions.filter((submission) => submission.submission_status === "submitted").length,
    inReview: submissions.filter((submission) => submission.submission_status === "in_review").length,
    completed: submissions.filter((submission) => submission.submission_status === "completed").length
  };
}

export function getSubmissionById(id: string) {
  const existing = demoSubmissions.find((submission) => submission.id === id);

  if (existing) {
    return existing;
  }

  return {
    id,
    customer_name: "New Customer",
    customer_email: "customer@example.com",
    sport: "Basketball",
    position: "Wing",
    video_url: null,
    video_file_path: "pending-upload.mov",
    notes: "Recent submission created in demo mode. Connect Supabase to persist uploaded footage and notes.",
    stripe_checkout_session_id: "cs_demo_new",
    payment_status: "paid",
    submission_status: "submitted",
    feedback_text: null,
    feedback_video_url: null,
    feedback_video_file_path: null,
    created_at: now.toISOString(),
    updated_at: now.toISOString(),
    completed_at: null
  } satisfies Submission;
}
