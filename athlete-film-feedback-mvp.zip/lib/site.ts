export const siteConfig = {
  name: "FrameIQ",
  tagline: "Upload your film. Receive expert analysis.",
  description:
    "Premium technical feedback on sports footage from a single elite athlete.",
  priceLabel: "$149",
  priceDescription: "One personalized film breakdown with written notes and optional video response."
};
