import type { OrderPayload } from "@/types";

export async function createCheckoutSession(order: OrderPayload) {
  const stripeEnabled = Boolean(process.env.STRIPE_SECRET_KEY && process.env.NEXT_PUBLIC_STRIPE_PRICE_ID);

  if (!stripeEnabled) {
    return {
      sessionId: `cs_demo_${Date.now()}`,
      checkoutUrl: `/checkout/success?submissionId=sub_${Date.now()}&demo=1`,
      mode: "demo" as const,
      order
    };
  }

  // Connect the official Stripe SDK here and create a Checkout Session.
  return {
    sessionId: `cs_live_placeholder_${Date.now()}`,
    checkoutUrl: `/checkout/success?submissionId=sub_${Date.now()}`,
    mode: "live" as const,
    order
  };
}
